﻿export enum ChangeType {
    Increment = 1,
    Update = 0,
    Decrement = -1
}
