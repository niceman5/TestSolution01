﻿export enum CounterType {
    Youtube,
    Blog
}
